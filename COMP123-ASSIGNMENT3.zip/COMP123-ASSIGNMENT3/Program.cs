﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMP123_ASSIGNMENT3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine();
            GiantPlanet giant = new GiantPlanet("Monster",84238.434d,3481484.413d,"Ice");
            Console.WriteLine(giant.ToString());

            Console.WriteLine();

            TerrestrialPlanet terrestrial = new TerrestrialPlanet("Earth", 58281372.525d, 364963.644d, true);
            Console.WriteLine(terrestrial.ToString());

            waitForAnyKey();

        }
        private static void waitForAnyKey()
        {
            Console.Write("\n");
            Console.WriteLine("++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
            Console.WriteLine("Please hit any key to exit....");
            Console.ReadKey();
        }
    }
}
